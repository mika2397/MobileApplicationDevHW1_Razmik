package com.example.java;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void ConvertToText(View view) {
        EditText editTextInput = (EditText) findViewById(R.id.editTextMain);
        String editTextResult = editTextInput.getText().toString();
        String finalResult = ConvertToFinalResult(editTextResult);
        TextView textViewInput = (TextView) findViewById(R.id.textViewMain);
        textViewInput.setText(finalResult);
    }

    public String ConvertToFinalResult(String s) {
        if(!isNumber(s) || s == null || s.length() == 0 || s.length()>9) {
            TextView textViewInput = (TextView) findViewById(R.id.textViewMain);
            textViewInput.setText("Invalid input, put in an actual number");
            System.exit(0);
        }

        int[] numbers = new int[s.length()];

        //loop to get array of integers from the string
        for (int i = 0; i < numbers.length; i++) {
            char c = s.charAt(i);
            numbers[i] = Character.getNumericValue(c);
        }

        String result = "";
        if(numbers.length < 3) {
            for(int k = 0; k < numbers.length; k++) {
                if(k == 0 && numbers.length == 1) {
                    result.concat(" " +PrintNumberIndividual(numbers[k]));
                }
                else if(numbers.length == 2) {
                    result.concat(" " + PrintNumberLessThanTwenty(numbers[k]));
                }
                else {
                    result.concat(" " +PrintNumberIndividual(numbers[k]));
                    result.concat(" Hundred ");
                }
            }
        }
        else  {
            for(int l = 0; l < numbers.length; l++) {
                if(l == 0 || l == 3 || l == 6) {
                    result.concat(" " +PrintNumberIndividual(numbers[l]));
                    result.concat(" Hundred ");
                }
                if( l ==4 || l == 7) {
                    result.concat(" " + PrintNumberLessThanTwenty(numbers[l]));
                    result.concat(" Hundred Thousand" );
                    result.concat(" " +PrintNumberIndividual(numbers[l++]));
                    result.concat(" Hundred ");
                }
                if( l == 2 ) {
                    result.concat(" " +PrintNumberIndividual(numbers[l]));
                    result.concat(" Million ");
                    result.concat(" " +PrintNumberIndividual(numbers[l++]));
                    result.concat(" Hundred ");
                    result.concat(" " + PrintNumberLessThanTwenty(numbers[l++]));
                    result.concat(" Hundred Thousand" );
                    result.concat(" " +PrintNumberIndividual(numbers[l++]));
                    result.concat(" Hundred ");
                }
            }
        }
        return result;
    }

    public boolean isNumber(String text) {
        for(int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if(!Character.isDigit(c)) {
                TextView textViewInput = (TextView) findViewById(R.id.textViewMain);
                textViewInput.setText("Invalid input, put in an actual number");
                return false;
            }
        }
        return true;
    }


    public String PrintNumberIndividual(int val) {
        switch (val) {
            case 1: return "one";
            case 2: return "two";
            case 3: return "three";
            case 4: return "four";
            case 5: return "five";
            case 6: return "six";
            case 7: return "seven";
            case 8: return "eight";
            case 9: return "nine";
        }
        return null;
    }

    public String PrintNumberLessThanTwenty(int val) {
        switch (val) {
            case 11: return "eleven";
            case 12: return "twelve";
            case 13: return "thirteen";
            case 14: return "fourteen";
            case 15: return "fifteen";
            case 16: return "sixteen";
            case 17: return "seventeen";
            case 18: return "eighteen";
            case 19: return "nineteen";
        }
        return null;
    }

    public String PrintNumberTens(int val) {
        switch (val) {
            case 20: return "twenty";
            case 30: return "thirty";
            case 40: return "forty";
            case 50: return "fifty";
            case 60: return "sixty";
            case 70: return "seventy";
            case 80: return "eighty";
            case 90: return "ninety";

        }
        return null;
    }

    public enum Hundreds {HUNDRED,THOUSAND,MILLION}

}